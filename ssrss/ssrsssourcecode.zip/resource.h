//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ssrss.rc
//
#define ID_SAVE                         2
#define IDRSS                           3
#define IDLoad                          4
#define ID_Close                        5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SSRSS_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDD_RSSOPTIONS                  129
#define IDC_HTTP                        130
#define IDC_FILEBOX                     1000
#define IDC_EDIT_DESC                   1001
#define IDC_EDIT_COPYRIGHT              1002
#define IDC_EDIT_WEBMASTER              1003
#define IDC_LIST_ENTRIES                1005
#define IDC_RSS_EDIT_MAIN               1007
#define IDC_RSS_TITLE                   1009
#define IDC_ADD_ENTRY                   1010
#define IDC_RSS_TTL                     1010
#define IDC_INSERT_LINK                 1011
#define IDC_DELETE_ENTRY                1012
#define IDC_EDIT_LINK                   1013
#define IDC_RSS_ENTRY_TITLE             1013
#define IDC_NEW_ENTRY                   1014
#define IDC_HTTP_EDIT                   1015
#define IDC_CLEAR                       1015
#define IDC_BUTTON1                     1016
#define IDC_RSS_ENTRY_TIME              1017
#define IDC_STATIC_CHANNEL_TITLE        1018
#define IDC_STATIC_ENTRY_TIME           1019
#define IDC_STATIC_ENTRY_TITLE          1020
#define IDC_STATIC_ENTRY_BOX            1021
#define IDC_EDIT1                       1022
#define IDC_RSS_ENTRY_LINK              1022
#define IDC_STATIC_ENTRY_Link           1023
#define IDC_UPDATE_ENTRY                1024
#define IDC_BUTTON_DOWN                 1026
#define IDC_BUTTON_UP                   1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
